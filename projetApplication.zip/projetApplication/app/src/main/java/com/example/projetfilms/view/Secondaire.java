package com.example.projetfilms.view;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetfilms.R;
import com.example.projetfilms.models.Film;
import com.example.projetfilms.models.Resultat;

import java.util.List;

public class Secondaire extends AppCompatActivity {

    private ListView listeFilms;
    private String []data;
    private TextView titre;
    private ListeAdapter adapter;
    private Button retour;
    private List<Film> liste_genre;

    static class ViewHolder {
        TextView textview;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondaire);

        Bundle extras = getIntent().getExtras();
        titre = findViewById(R.id.titre);
        retour = findViewById(R.id.retour);

        listeFilms = findViewById(R.id.liste);
        Resultat result = getIntent().getParcelableExtra("liste");
        adapter = new ListeAdapter(this,result.getResults());
        listeFilms.setAdapter(adapter);

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        listeFilms.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent intent = new Intent(Secondaire.this, Tertiaire.class);
                intent.putExtra("film", adapter.getItem(position));
                System.out.println(adapter.getItem(position));
                startActivity(intent);
            }
        });
    }

    public class ListeAdapter extends ArrayAdapter<Film> {
        LayoutInflater inflater;

        public ListeAdapter(Activity active, List<Film> liste){
            super(active, R.layout.filmitem, liste);
            inflater = LayoutInflater.from(active);


        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
            View v = convertView;
            ViewHolder vh;

            if (v == null) {
                v=inflater.inflate(R.layout.filmitem, parent,false);
                vh = new ViewHolder();
                vh.textview = v.findViewById(R.id.titre);
                v.setTag(vh);

            }
            else {
                vh = (ViewHolder) v.getTag();
            }
            Film p = getItem(position);

            TextView textview = vh.textview;
            textview.setText(p.getTitle());

            return v;
        }
    }


}
