package com.example.projetfilms.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projetfilms.R;
import com.example.projetfilms.models.Film;
import com.example.projetfilms.models.Resultat;
import com.squareup.picasso.Picasso;

public class Tertiaire extends AppCompatActivity {

    private TextView titre;
    private ImageView image;
    private TextView resume;
    private Button retour;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informations);

        retour = findViewById(R.id.retour);
        titre = findViewById(R.id.text);
        image = findViewById(R.id.imageFilm);
        resume = findViewById(R.id.resume);

        Film film = getIntent().getParcelableExtra("film");
        titre.setText(film.getTitle());
        Picasso.get().load("https://image.tmdb.org/t/p/w500/"+film.getBackdropPath()).into(image);
        resume.setText(film.getOverview());

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}

