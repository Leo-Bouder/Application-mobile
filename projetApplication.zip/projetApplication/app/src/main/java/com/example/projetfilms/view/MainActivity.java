package com.example.projetfilms.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projetfilms.R;
import com.example.projetfilms.models.Film;
import com.example.projetfilms.models.Resultat;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private SeekBar seekbar;
    private TextView seekbar_valeur;
    private Button research;
    private TextView mot;
    private EditText date;
    private String url;
    private String api;
    private Spinner genre;
    private EditText page;
    private int idGenre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        page = findViewById(R.id.page_valeur);
        ArrayList<Film> filmList = new ArrayList<>();
        api = "737693c04656fdf512002c5741874c7d";
        url = "www.themoviedb.org";
        genre = findViewById(R.id.spinner);


        mot = findViewById(R.id.mot);
        date = findViewById(R.id.date_nombre);


        Map<String, Integer> genres = new HashMap<String, Integer>();
        genres.put("ACTION", 28);
        genres.put("ADVENTURE", 12);
        genres.put("ANIMATION", 16);
        genres.put("COMEDY", 35);
        genres.put("CRIME", 80);
        genres.put("DOCUMENTARY", 99);
        genres.put("DRAMA", 18);
        genres.put("FAMILY", 10751);
        genres.put("FANTASY", 14);
        genres.put("HISTORY", 36);
        genres.put("HORROR", 27);
        genres.put("MUSIC", 10402);
        genres.put("MYSTERY", 9648);
        genres.put("ROMANCE", 10749);
        genres.put("SCIENCE FICTION", 878);
        genres.put("TV MOVIE", 10770);
        genres.put("THRILLER", 53);
        genres.put("WAR", 10752);
        genres.put("WESTERN", 37);




        ArrayList<String> data = new ArrayList<>();
        spinner = findViewById(R.id.spinner);
        data.add("ACTION");
        data.add("ADVENTURE");
        data.add("ANIMATION");
        data.add("COMEDY");
        data.add("CRIME");
        data.add("DOCUMENTARY");
        data.add("DRAMA");
        data.add("FAMILY");
        data.add("FANTASY");
        data.add("HISTORY");
        data.add("HORROR");
        data.add("MUSIC");
        data.add("MYSTERY");
        data.add("ROMANCE");
        data.add("SCIENCE FICTION");
        data.add("TV MOVIE");
        data.add("THRILLER");
        data.add("WAR");
        data.add("WESTERN");
        ArrayAdapter<String> aa;
        aa = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, data);
        spinner.setAdapter(aa);

        seekbar = findViewById(R.id.seekBar);
        seekbar_valeur = findViewById(R.id.seekbar_valeur);
        seekbar_valeur.setText("1");
        seekbar.setMax(20);
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                String test = String.valueOf(seekbar.getProgress());
                seekbar_valeur.setText(test);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



        research = findViewById(R.id.research);
        research.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                idGenre = genres.get(genre.getSelectedItem());
                System.out.println(idGenre);
                System.out.println("Test");
                int page_val = Integer.parseInt(page.getText().toString());
                if (seekbar_valeur.getText().toString() != "0" && mot.getText().length() != 0) {
                    System.out.println("First if loop");
                    if (true) {
                        System.out.println("Second if loop");
                        System.out.println("First for loop");
                        Ion.with(getApplicationContext())
                                .load("https://api.themoviedb.org/3/search/movie?api_key=737693c04656fdf512002c5741874c7d&language=en-US&query=spiderman&page="+page_val+"&include_adult=false")
                                .asJsonObject()
                                .setCallback(new FutureCallback<JsonObject>() {
                                    @Override
                                    public void onCompleted(Exception e, JsonObject result) {
                                        System.out.println("Query completed");
                                        Gson gson = new Gson();
                                        Resultat result1 = gson.fromJson(result, Resultat.class);
                                        if((result1.getResults().size() < Integer.parseInt(seekbar_valeur.getText().toString())) && (!result1.getResults().isEmpty())) {
                                            for (int h = 0; h < result1.getResults().size(); h++) {
                                                for(int j = 0; j < result1.getResults().get(h).getGenreIds().size(); j++){
                                                    if((!filmList.contains(result1.getResults().get(h))) && result1.getResults().get(h).getGenreIds().get(j) == idGenre){
                                                        filmList.add(result1.getResults().get(h));
                                                    }
                                                }
                                            }
                                        }
                                        else if(result1.getResults().size() > Integer.parseInt(seekbar_valeur.getText().toString()) && (!result1.getResults().isEmpty())){
                                            for (int h = 0; h < Integer.parseInt(seekbar_valeur.getText().toString())-1; h++) {
                                                for(int j = 0; j < result1.getResults().get(h).getGenreIds().size(); j++){
                                                    if((!filmList.contains(result1.getResults().get(h))) && result1.getResults().get(h).getGenreIds().get(j) == idGenre){
                                                        filmList.add(result1.getResults().get(h));
                                                    }
                                                }
                                            }
                                        }

                                        System.out.println(filmList);

                                        result1.setResults(filmList);
                                        Intent intent = new Intent(MainActivity.this, Secondaire.class);
                                        intent.putExtra("nb", Integer.parseInt(seekbar_valeur.getText().toString()));
                                        intent.putExtra("liste", result1);
                                        startActivity(intent);
                                    }
                                });


                    } else {
                        Ion.with(view.getContext())
                                .load("https://api.themoviedb.org/3/search/movie?api_key=" + api + "&language=en-US&page=1&include_adult=false&query=" + mot.getText().toString() + "&language=fr-FR&year=" + date.getText().toString())
                                .asJsonObject()
                                .setCallback(new FutureCallback<JsonObject>() {
                                    @Override
                                    public void onCompleted(Exception e, JsonObject result) {
                                        // do stuff with the result or error
                                        Gson gson = new Gson();
                                        Resultat result1 = gson.fromJson(result, Resultat.class);
                                        if (Integer.parseInt(seekbar_valeur.getText().toString()) < 20) {
                                            for (int h = 0; h < 19; h++) {
                                                filmList.add(result1.getResults().get(h));
                                            }
                                        }
                                        result1.setResults(filmList);
                                        Intent intent = new Intent(MainActivity.this, Secondaire.class);
                                        intent.putExtra("nb", Integer.parseInt(seekbar_valeur.getText().toString()));
                                        intent.putExtra("liste", result1);
                                        startActivity(intent);

                                    }
                                });

                    }
                } else {
                    Toast toast = Toast.makeText(MainActivity.this, "Veuillez saisir un nombre de film supérieur à 0 et un nom de film", Toast.LENGTH_LONG);
                    toast.show();
                }

            }
            });
    }



}